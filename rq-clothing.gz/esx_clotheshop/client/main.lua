local HasAlreadyEnteredMarker = false
local LastZone                = nil
local CurrentAction           = nil
local CurrentActionMsg        = ''
local CurrentActionData       = {}
local HasPaid                = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(500)
	end
end)

local shopTypes = {
	{ label = _U('default'), value = 'default', event = 'esx_clotheshop:openMenu' }
}

AddEventHandler("esx_clotheshop:registerShopType", function(data)
	table.insert(shopTypes, data)
end)

function ChooseShopType()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'choose_shop',
	{
		title = _U('choose_shop'),
		align = 'top-right',
		elements = shopTypes
	}, function(data, menu)
		menu.close()

		TriggerEvent(data.current.event, data.current.value, function()
			ChooseShopType()
		end)
	end, function(data, menu)
		menu.close()

		SetCurrentAction('shop_menu', _U('press_menu'), {})
	end)
end

AddEventHandler("esx_clotheshop:openMenu", function(data, cb)
	OpenShopMenu(data, cb)
end)

function ConfirmMenu(message)
	message = message or 'Kledingstuk bestaat al, overschrijven?'
	local p = promise.new()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'shop_confirm',
	{
		title = message,
		align = 'top-right',
		elements = {
			{label = _U('no'), value = 'no'},
			{label = _U('yes'), value = 'yes'}
		}
	}, function(confirmData, confirmMenu)
		if confirmData.current.value and confirmData.current.value == "yes" then
			p:resolve(true)
        else
            ESX.ShowNotification("Naam ~r~niet correct~s~ overgetypt, actie geannulleerd.")
			p:resolve(false)
		end
		confirmMenu.close()
	end, function (confirmData, confirmMenu)
        confirmMenu.close()
		p:resolve(false)
	end,
	false,
	function()
		p:resolve(false)
	end)

	return Citizen.Await(p)
end

function OpenShopMenu(data, cb)
	HasPaid = false
    TriggerEvent("afkkick:Cancel", "esx_clothesshop")
	TriggerEvent('esx_skin:openRestrictedMenu', function(data, menu)
		menu.close()

		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'shop_confirm',
		{
			title = _U('valid_this_purchase'),
			align = 'top-right',
			elements = {
				{label = _U('no'), value = 'no'},
				{label = _U('yes'), value = 'yes'}
			}
		}, function(data, menu)
            menu.close()
            TriggerEvent("afkkick:Resume", "esx_clothesshop")

			if data.current.value == 'yes' then
				ESX.TriggerServerCallback('esx_clotheshop:buyClothes', function(bought)
					if bought then
						TriggerEvent('skinchanger:getSkin', function(skin)
							TriggerServerEvent('esx_skin:save', skin)
						end)

						HasPaid = true

						ESX.TriggerServerCallback('esx_clotheshop:checkPropertyDataStore', function(foundStore)
							if foundStore then
								ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'save_dressing', {
									title = _U('save_in_dressing'),
									align = 'top-left',
									elements = {
										{label = _U('no'),  value = 'no'},
										{label = _U('yes'), value = 'yes'}
								}}, function(data2, menu2)
									menu2.close()

									if data2.current.value == 'yes' then
										ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'outfit_name', {
											title = _U('name_outfit')
										}, function(data3, menu3)
											menu3.close()

											TriggerEvent('skinchanger:getSkin', function(skin)
												TriggerServerEvent('esx_clotheshop:saveOutfit', data3.value, skin)
												ESX.ShowNotification(_U('saved_outfit'))
											end)
										end, function(data3, menu3)
											menu3.close()
										end)
									end
								end)
							end
						end)

					else
						ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
							if not skin then
								error("skin is nil")
							end
							TriggerEvent('skinchanger:loadSkin', skin)
						end)

						ESX.ShowNotification(_U('not_enough_money'))
					end
				end)
			elseif data.current.value == 'no' then
				ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
					if not skin then
						error("skin is nil")
					end
					TriggerEvent('skinchanger:loadSkin', skin)
				end)
			end

			if cb then
				cb()
			else
				SetCurrentAction('shop_menu', _U('press_menu'), {})
			end
		end, function(data, menu)
			menu.close()

			if cb then
				cb()
			else
				SetCurrentAction('shop_menu', _U('press_menu'), {})
			end
		end)

    end, function(data, menu)
        TriggerEvent("afkkick:Resume", "esx_clothesshop")
		menu.close()

		if cb then
			cb()
		else
			SetCurrentAction('shop_menu', _U('press_menu'), {})
		end
	end, {
		'tshirt_1',
		'tshirt_2',
		'torso_1',
		'torso_2',
		'decals_1',
		'decals_2',
		'arms',
		'arms_2',
		'pants_1',
		'pants_2',
		'shoes_1',
		'shoes_2',
		'chain_1',
		'chain_2',
		'helmet_1',
		'helmet_2',
		'glasses_1',
		'glasses_2',
		'ears_1',
		'ears_2',
        'bag_1',
        'bag_2',
		'watches_1',
		'watches_2',
		'bracelets_1',
		'bracelets_2',
		'bproof_1',
		'bproof_2',
	})

end

AddEventHandler('esx_clotheshop:hasEnteredMarker', function(zone)
	SetCurrentAction('shop_menu', _U('press_menu'), {})
end)

AddEventHandler('esx_clotheshop:hasExitedMarker', function(zone)
	ESX.UI.Menu.CloseAll()
	SetCurrentAction(nil, nil, nil)

	if not HasPaid then
		TriggerEvent('esx_skin:getLastSkin', function(skin)
			if not skin then
				-- Causes errors, if somebody simply walks through the circle
				return
			end
			TriggerEvent('skinchanger:loadSkin', skin)
		end)
	end
end)

-- Create Blips
Citizen.CreateThread(function()
	AddTextEntry("BLIP_CLOTHESSHOP", _U('clothes'))
	for i=1, #Config.Shops, 1 do
		local blip = AddBlipForCoord(Config.Shops[i].x, Config.Shops[i].y, Config.Shops[i].z)

		SetBlipSprite (blip, 73)
		SetBlipDisplay(blip, 4)
		SetBlipScale  (blip, 0.85)
		SetBlipColour (blip, 47)
		SetBlipAsShortRange(blip, true)

		BeginTextCommandSetBlipName("BLIP_CLOTHESSHOP")
		EndTextCommandSetBlipName(blip)
	end
end)

-- Display markers
local function markerTick()
	local coords = GetEntityCoords(PlayerPedId())
	local minDistance = 5000
	local isInMarker  = false
	local currentZone = nil

	for k,v in pairs(Config.Zones) do
		local distance = #(coords - vector3(v.Pos.x, v.Pos.y, v.Pos.z))
		if(v.Type ~= -1 and distance < Config.DrawDistance) then
			if(distance < v.Size.x) then
				isInMarker  = true
				currentZone = k
			end
			DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 100, false, true, 2, false, false, false, false)
		end
		minDistance = math.min(minDistance, distance)
	end

	if (isInMarker and not HasAlreadyEnteredMarker) or (isInMarker and LastZone ~= currentZone) then
		HasAlreadyEnteredMarker = true
		LastZone                = currentZone
		TriggerEvent('esx_clotheshop:hasEnteredMarker', currentZone)
	end

	if not isInMarker and HasAlreadyEnteredMarker then
		HasAlreadyEnteredMarker = false
		TriggerEvent('esx_clotheshop:hasExitedMarker', LastZone)
	end

	if minDistance > Config.DrawDistance then
		return 15 * minDistance ^ 1.3
	end
end

local markerThread = Thread:new(markerTick, "markerThread")
markerThread:useTicker()
markerThread:start()

local function keyTick(thread)
	if not CurrentAction then
		thread:stop()
		return
	end

	ESX.ShowHelpNotification(CurrentActionMsg)

	if IsControlJustReleased(0, 38) then
		if CurrentAction == 'shop_menu' then
			ChooseShopType()
		end

		CurrentAction = nil
	end
end

local keyThread = Thread:new(keyTick)

function SetCurrentAction(currentAction, currentActionMsg, currentActionData)
	CurrentAction = currentAction
	CurrentActionMsg = currentActionMsg
	CurrentActionData = currentActionData

	if CurrentAction then
		keyThread:start()
	else
		keyThread:stop()
	end
end
