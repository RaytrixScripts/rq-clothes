Locales['en'] = {
	['valid_this_purchase'] = 'Ben je er zeker van?',
	['yes'] = 'ja',
	['no'] = 'nee',
	['not_enough_money'] = 'Je hebt niet genoeg geld',
	['press_menu'] = 'Druk ~INPUT_CONTEXT~ om het menu te bedienen',
	['clothes'] = 'kleren',
	['default'] = 'Kleding winkel',
	['you_paid'] = 'Je betaalde ~g~$%s~s~',
	['save_in_dressing'] = 'Wil je de outfit opslaan?',
	['name_outfit'] = 'Geef je outfit een naam',
	['saved_outfit'] = 'De outfit is opgeslagen!',
	['choose_shop'] = 'Welk type outfit wil je kopen?'
}