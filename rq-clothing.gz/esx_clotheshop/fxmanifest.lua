fx_version 'adamant'
game 'gta5'

description 'ESX ClotheShop'

version '1.1.0'

client_scripts {
	'@esx_boilerplate/natives.lua',
	'@es_extended/locale.lua',
	'@esx_boilerplate/utils/logger.lua',
	'@esx_boilerplate/utils/threads.lua',
	'@esx_boilerplate/utils/lazy_esx.lua',
	'locales/en.lua',
	'config.lua',
	'client/main.lua'
}

server_scripts {
	'@esx_boilerplate/natives_server.lua',
	'@anticheat/event_s.lua',
	'@mysql-async/lib/MySQL.lua',
	'@es_extended/locale.lua',
	'@esx_datastore/lib/datastore.lua',
	'@esx_boilerplate/utils/lazy_esx.lua',
	'locales/en.lua',
	'config.lua',
	'server/main.lua'
}

dependencies {
	'es_extended',
	'esx_skin'
}