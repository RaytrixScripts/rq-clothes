ESX = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx_clothes:shirt')
AddEventHandler('esx_clothes:shirt', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['tshirt_1'] = 15, ['tshirt_2'] = 0,
			['torso_1'] = 15, ['torso_2'] = 0,
			['arms'] = 15, ['arms_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:shirt')
AddEventHandler('esx_clothes:shirt', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['tshirt_1'] = 15, ['tshirt_2'] = 0,
			['torso_1'] = 15, ['torso_2'] = 0,
			['arms'] = 15, ['arms_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:broek')
AddEventHandler('esx_clothes:broek', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['pants_1'] = 21, ['pants_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:hoed')
AddEventHandler('esx_clothes:hoed', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['helmet_1'] = -1, ['helmet_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:holster')
AddEventHandler('esx_clothes:holster', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['chain_1'] = -1, ['chain_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:rugtas')
AddEventHandler('esx_clothes:rugtas', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['bags_1'] = 0, ['bags_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)


RegisterNetEvent('esx_clothes:schoenen')
AddEventHandler('esx_clothes:schoenen', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['shoes_1'] = 34, ['shoes_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:bril')
AddEventHandler('esx_clothes:bril', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['glasses_1'] = 0, ['glasses_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

RegisterNetEvent('esx_clothes:masker')
AddEventHandler('esx_clothes:masker', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
		local clothesSkin = {
			['mask_1'] = 0, ['mask_2'] = 0
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)

function openAccessoriesMenu(target)
	local elements = {}
	table.insert(elements, {label = ('Doe kleding aan'), value = 'reset'})
	table.insert(elements, {label = ('--- Verwijder ---'), value = 'none'})
	table.insert(elements, {label = ('Verwijder hoed'), value = 'hoed'})
	table.insert(elements, {label = ('Verwijder ketting/holster'), value = 'holster'})
	table.insert(elements, {label = ('Verwijder masker'), value = 'masker'})
	table.insert(elements, {label = ('Verwijder bril'), value = 'bril'})
	table.insert(elements, {label = ('Verwijder rugtas'), value = 'rugtas'})
	ESX.UI.Menu.CloseAll()
	ESX.UI.Menu.Open(
		'default', GetCurrentResourceName(), 'clothing_menu1',
		{
			title    = ('Kleding'),
			align    = 'top-right',
			elements = elements
		},
	function(data,menu)
		if data.current.value == 'reset' then
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
					TriggerEvent('skinchanger:loadSkin', skin)
				end)
				ESX.UI.Menu.CloseAll()
			else
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
			end
		elseif data.current.value == "hoed" then 
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent("esx_clothes:hoed")
				ESX.UI.Menu.CloseAll()
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		elseif data.current.value == "holster" then 
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent("esx_clothes:holster")
				ESX.UI.Menu.CloseAll()
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		elseif data.current.value == "bril" then 
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent("esx_clothes:bril")
				ESX.UI.Menu.CloseAll()
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		elseif data.current.value == "rugtas" then 
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent("esx_clothes:rugtas")
				ESX.UI.Menu.CloseAll()
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		elseif data.current.value == "masker" then 
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent("esx_clothes:masker")
				ESX.UI.Menu.CloseAll()
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		end
	end)
end

function openMenu(target)
	local elements = {}
	table.insert(elements, {label = ('Kleding'), value = 'kleding'})
	table.insert(elements, {label = ('Accessories'), value = 'accessories'})
	ESX.UI.Menu.CloseAll()
	ESX.UI.Menu.Open(
		'default', GetCurrentResourceName(), 'clothing_menu',
		{
			title    = ('Kleding'),
			align    = 'top-right',
			elements = elements
		},
	function(data,menu)
		if data.current.value == "kleding" then 
			ESX.UI.Menu.CloseAll()
			OpenActionMenuInteraction()
		elseif data.current.value == "accessories" then 
			ESX.UI.Menu.CloseAll()
			openAccessoriesMenu()
		end
	end)
end

function OpenActionMenuInteraction(target)
	local elements = {}
	table.insert(elements, {label = ('Doe kleding aan'), value = 'reset'})
	table.insert(elements, {label = ('--- Verwijder ---'), value = 'none'})
	table.insert(elements, {label = ('Verwijder shirt'), value = 'shirt'})
	table.insert(elements, {label = ('Verwijder broek'), value = 'broek'})
	table.insert(elements, {label = ('Verwijder schoenen'), value = 'but'})
  	ESX.UI.Menu.CloseAll()	
	ESX.UI.Menu.Open(
		'default', GetCurrentResourceName(), 'clothing_menu2',
		{
			title    = ('Kleding'),
			align    = 'top-right',
			elements = elements
		},
    function(data, menu)
		if data.current.value == 'reset' then
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
					TriggerEvent('skinchanger:loadSkin', skin)
				end)
				ESX.UI.Menu.CloseAll()	
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		elseif data.current.value == 'shirt' then
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent('esx_clothes:shirt')
				ESX.UI.Menu.CloseAll()	
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
		elseif data.current.value == 'broek' then
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent('esx_clothes:broek')
				ESX.UI.Menu.CloseAll()
			else
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end	
		elseif data.current.value == 'but' then
			if not IsPedWalking(PlayerPedId(), false) then 
				ExecuteCommand("e shakeoff")
				Wait(1500)
				TriggerEvent('esx_clothes:schoenen')
				ESX.UI.Menu.CloseAll()	
			else 
				ESX.ShowNotification("~r~Dit kan niet tijdens het lopen.")
				ESX.UI.Menu.CloseAll()
			end
	  	end
	end)
end

Citizen.CreateThread(function()
	while true do 
		Citizen.Wait(5)
		if IsControlJustReleased(0, 344) and not ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'clothing_menu') then
			openMenu()
		elseif ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'clothing_menu') and IsControlJustReleased(0, 177) then
			ESX.UI.Menu.CloseAll()
		elseif ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'clothing_menu2') and IsControlJustReleased(0, 177) then
			openMenu()
		elseif ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'clothing_menu1') and IsControlJustReleased(0, 177) then
			openMenu()
		end
	end
end)