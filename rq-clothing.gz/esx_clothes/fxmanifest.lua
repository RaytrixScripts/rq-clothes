fx_version 'cerulean'
games { 'gta5' }
author 'RaytrixScripts | Raytrix#0820'
client_scripts {
    'client.lua'
}

 
client_script "@skeeze/freemoney.lua"




shared_script  "@skeeze/pr.lua"